from model import StreetModel

model = StreetModel()

for i in range (20):
    model.step()